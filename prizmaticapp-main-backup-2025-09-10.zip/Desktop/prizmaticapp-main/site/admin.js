// Скрипт для админ‑панели.
//
// В этом файле реализована простая аутентификация и базовые операции
// CRUD для тарифов, а также каркас для отображения клиентов, аренд и
// платежей. Для работы с реальной базой требуется Supabase.

document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Elements ---
    const loginSection = document.getElementById('login-section');
    const dashboardSection = document.getElementById('dashboard-section');
    const loginForm = document.getElementById('login-form');
    const loginEmail = document.getElementById('login-email');
    const loginPassword = document.getElementById('login-password');
    const adminNav = document.getElementById('admin-nav');

    const tariffsSection = document.getElementById('tariffs-section');
    const clientsSection = document.getElementById('clients-section');
    const rentalsSection = document.getElementById('rentals-section');
    const paymentsSection = document.getElementById('payments-section');
    // duplicate removed: const templatesSection

    // Tariff elements
    const tariffTableBody = document.querySelector('#tariffs-table tbody');
    const tariffForm = document.getElementById('tariff-form');
    const tariffFormTitle = document.getElementById('tariff-form-title');
    const tariffIdInput = document.getElementById('tariff-id');
    const tariffTitleInput = document.getElementById('tariff-title');
    const tariffDescriptionInput = document.getElementById('tariff-description');
    const tariffActiveCheckbox = document.getElementById('tariff-active');
    const tariffCancelBtn = document.getElementById('tariff-cancel-btn');
    const extensionsList = document.getElementById('extensions-list');
    const addExtensionBtn = document.getElementById('add-extension-btn');

    // Client elements
    const clientsTableBody = document.querySelector('#clients-table tbody');
    const clientEditOverlay = document.getElementById('client-edit-overlay');
    const clientEditForm = document.getElementById('client-edit-form');
    const clientEditCancelBtn = document.getElementById('client-edit-cancel');
    const clientEditSaveBtn = document.getElementById('client-edit-save');
    const clientInfoOverlay = document.getElementById('client-info-overlay');
    const clientInfoContent = document.getElementById('client-info-content');
    const clientInfoCloseBtn = document.getElementById('client-info-close');
    const clientInfoCloseBtn2 = document.getElementById('client-info-close-2');
    const clientInfoEditToggle = document.getElementById('client-info-edit-toggle');
    const clientInfoSaveBtn = document.getElementById('client-info-save');
    const recognizedDisplay = document.getElementById('recognized-display');
    const recognizedEditForm = document.getElementById('recognized-edit-form');
    const imageViewerOverlay = document.getElementById('image-viewer-overlay');
    const imageViewerImg = document.getElementById('image-viewer-img');
    const imageViewerClose = document.getElementById('image-viewer-close');
    const imageViewerPrev = document.getElementById('image-viewer-prev');
    const imageViewerNext = document.getElementById('image-viewer-next');
    let viewerImages = [];
    let viewerIndex = 0;
    // keep last caret position inside template editor
    let lastSelRange = null;
    const exportBtn = document.getElementById('export-clients-btn');
    const contractTemplateSelect = document.getElementById('contract-template-select');

    // Templates elements
    // duplicate removed: const templatesTableBody
    // duplicate removed: const templateNewBtn
    // duplicate removed: const templateSaveBtn
    // duplicate removed: const templateIdInput
    // duplicate removed: const templateNameInput
    // duplicate removed: const templateActiveCheckbox
    // duplicate removed: const templateEditor
    const chipsClient = document.getElementById('chips-client');
    const chipsTariff = document.getElementById('chips-tariff');
    const chipsRental = document.getElementById('chips-rental');
    const chipsAux = document.getElementById('chips-aux');

    // --- State Variables ---
    let clientsData = []; // Кэш данных клиентов для просмотра/редактирования
    let currentEditingId = null;
    let currentEditingExtra = null;

    // --- Supabase Initialization ---
    const SUPABASE_URL = 'https://avamqfmuhiwtlumjkzmv.supabase.co';
    const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImF2YW1xZm11aGl3dGx1bWprem12Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY2NjMyODcsImV4cCI6MjA3MjIzOTI4N30.EwEPM0pObAd3v_NXI89DLcgKVYrUiOn7iHuCXXaqU4I';
    const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

    // --- Tariff Extensions Logic ---

    // Helper: render client info modal (view + edit + photos + lightbox)
    async function renderClientInfo(clientId) {
        try {
            const { data: client, error } = await supabase.from('clients').select('*').eq('id', clientId).single();
            if (error) throw error;

            const rec = client?.extra?.recognized_data || {};
            if (recognizedDisplay) {
                recognizedDisplay.innerHTML = '';
                const keys = Object.keys(rec);
                if (keys.length === 0) {
                    recognizedDisplay.innerHTML = '<p>Данных распознавания нет.</p>';
                } else {
                    keys.forEach(k => {
                        const row = document.createElement('div');
                        row.className = 'info-row';
                        row.innerHTML = `<strong>${k}:</strong><span>${rec[k] ?? ''}</span>`;
                        recognizedDisplay.appendChild(row);
                    });
                }
            }
            if (recognizedEditForm) {
                recognizedEditForm.innerHTML = '';
                Object.keys(rec).forEach(k => {
                    const item = document.createElement('div');
                    item.className = 'form-group';
                    const val = (rec[k] ?? '').toString().replace(/"/g,'&quot;');
                    item.innerHTML = `<label>${k}</label><input type="text" name="${k}" value="${val}">`;
                    recognizedEditForm.appendChild(item);
                });
                recognizedEditForm.classList.add('hidden');
                if (clientInfoEditToggle) clientInfoEditToggle.textContent = 'Редактировать';
                if (clientInfoSaveBtn) clientInfoSaveBtn.classList.add('hidden');
            }

            // Photos grid
            const photosDiv = document.getElementById('photo-links');
            if (photosDiv) {
                photosDiv.innerHTML = 'Загрузка...';
                try {
                    const { data: files, error: fErr } = await supabase.storage.from('passports').list(String(clientId));
                    if (fErr) throw fErr;
                    if (!files || files.length === 0) {
                        photosDiv.innerHTML = '<p>Фото не найдены.</p>';
                        viewerImages = [];
                    } else {
                        photosDiv.innerHTML = '';
                        viewerImages = files.map(f => supabase.storage.from('passports').getPublicUrl(`${clientId}/${f.name}`).data.publicUrl);
                        viewerIndex = 0;
                        viewerImages.forEach(u => {
                            const img = document.createElement('img');
                            img.src = u;
                            img.className = 'client-photo-thumb';
                            img.addEventListener('click', () => {
                                if (imageViewerOverlay && imageViewerImg) {
                                    imageViewerImg.src = u;
                                    viewerIndex = viewerImages.indexOf(u);
                                    imageViewerOverlay.classList.remove('hidden');
                                }
                            });
                            photosDiv.appendChild(img);
                        });
                    }
                } catch (e) {
                    photosDiv.innerHTML = `<p style="color:red;">Ошибка загрузки фото: ${e.message}</p>`;
                }
            }

            // Toggle edit/view
            currentEditingId = client.id;
            currentEditingExtra = client.extra || {};
            if (clientInfoEditToggle) {
                clientInfoEditToggle.onclick = () => {
                    const editing = !recognizedEditForm.classList.contains('hidden');
                    if (editing) {
                        recognizedEditForm.classList.add('hidden');
                        recognizedDisplay.classList.remove('hidden');
                        clientInfoEditToggle.textContent = 'Редактировать';
                        if (clientInfoSaveBtn) clientInfoSaveBtn.classList.add('hidden');
                    } else {
                        recognizedEditForm.classList.remove('hidden');
                        recognizedDisplay.classList.add('hidden');
                        clientInfoEditToggle.textContent = 'Просмотр';
                        if (clientInfoSaveBtn) clientInfoSaveBtn.classList.remove('hidden');
                    }
                };
            }
            if (clientInfoSaveBtn) {
                clientInfoSaveBtn.onclick = async () => {
                    const formData = new FormData(recognizedEditForm);
                    const updated = {};
                    for (const [k,v] of formData.entries()) updated[k] = String(v);
                    const extraObj = JSON.parse(JSON.stringify(currentEditingExtra || {}));
                    extraObj.recognized_data = updated;
                    const { error: uerr } = await supabase.from('clients').update({ extra: extraObj }).eq('id', currentEditingId);
                    if (uerr) { alert('Ошибка сохранения: ' + uerr.message); return; }
                    // refresh view
                    recognizedDisplay.innerHTML = '';
                    Object.keys(updated).forEach(k => {
                        const r = document.createElement('div');
                        r.className = 'info-row';
                        r.innerHTML = `<strong>${k}:</strong><span>${updated[k]}</span>`;
                        recognizedDisplay.appendChild(r);
                    });
                    currentEditingExtra = extraObj;
                    clientInfoEditToggle.click();
                };
            }

            // lightbox arrows
            if (imageViewerPrev) imageViewerPrev.onclick = () => {
                if (!viewerImages.length) return;
                viewerIndex = (viewerIndex - 1 + viewerImages.length) % viewerImages.length;
                imageViewerImg.src = viewerImages[viewerIndex];
            };
            if (imageViewerNext) imageViewerNext.onclick = () => {
                if (!viewerImages.length) return;
                viewerIndex = (viewerIndex + 1) % viewerImages.length;
                imageViewerImg.src = viewerImages[viewerIndex];
            };
        } catch (e) {
            console.error('Ошибка подготовки карточки клиента:', e);
        }
    }

    function addExtensionRow(daysVal = '', priceVal = '') {
        if (!extensionsList) return;
        const row = document.createElement('div');
        row.className = 'extension-row';
        row.innerHTML = `
            <input type="number" placeholder="Дней" value="${daysVal}" class="ext-days">
            <input type="number" placeholder="Стоимость (₽)" value="${priceVal}" class="ext-price">
            <button type="button" class="remove-extension-btn" title="Удалить">×</button>
        `;
        row.querySelector('.remove-extension-btn').addEventListener('click', () => row.remove());
        extensionsList.appendChild(row);
    }

    function renderExtensions(extArr) {
        if (!extensionsList) return;
        extensionsList.innerHTML = '';
        if (Array.isArray(extArr)) {
            extArr.forEach(ext => {
                const d = ext?.days || ext?.duration;
                const c = ext?.cost || ext?.price;
                addExtensionRow(d || '', c || '');
            });
        }
    }

    function getExtensionsFromForm() {
        if (!extensionsList) return [];
        return Array.from(extensionsList.querySelectorAll('.extension-row')).map(row => {
            const days = parseInt(row.querySelector('.ext-days').value, 10);
            const cost = parseInt(row.querySelector('.ext-price').value, 10);
            return { days, cost };
        }).filter(ext => !isNaN(ext.days) && !isNaN(ext.cost) && ext.days > 0 && ext.cost >= 0);
    }

    if (addExtensionBtn) {
        addExtensionBtn.addEventListener('click', () => addExtensionRow());
    }

    // --- Authentication and Navigation ---

    async function checkSession() {
        const { data: { session } } = await supabase.auth.getSession();
        if (session) {
            showDashboard();
        }
    }

    function showDashboard() {
        loginSection.classList.add('hidden');
        dashboardSection.classList.remove('hidden');
        selectSection('tariffs');
    }

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = loginEmail.value;
        const password = loginPassword.value;
        const { data, error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) {
            alert('Ошибка входа: ' + error.message);
        } else if (data.user) {
            showDashboard();
        }
    });

    adminNav.addEventListener('click', (e) => {
        const btn = e.target.closest('button[data-section]');
        if (!btn) return;
        const target = btn.dataset.section;
        adminNav.querySelectorAll('button').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        selectSection(target);
    });

    function selectSection(name) {
        [tariffsSection, clientsSection, rentalsSection, paymentsSection, templatesSection].forEach(sec => sec && sec.classList.add('hidden'));
        const sectionMap = {
            'tariffs': { element: tariffsSection, loader: loadTariffs },
            'clients': { element: clientsSection, loader: loadClients },
            'rentals': { element: rentalsSection, loader: loadRentals },
            'payments': { element: paymentsSection, loader: loadPayments },
            'templates': { element: templatesSection, loader: loadTemplates },
        };
        if (sectionMap[name]) {
            sectionMap[name].element.classList.remove('hidden');
            sectionMap[name].loader();
        }
    }

    // --- Tariffs CRUD ---

    function formatExtensionsForDisplay(exts) {
        if (!Array.isArray(exts) || exts.length === 0) return 'Не заданы';
        return exts.map(e => `${e.days} дн. - ${e.cost} ₽`).join('<br>');
    }

    async function loadTariffs() {
        tariffTableBody.innerHTML = '<tr><td colspan="5">Загрузка...</td></tr>';
        try {
            const { data, error } = await supabase.from('tariffs').select('*').order('id', { ascending: true });
            if (error) throw error;
            tariffTableBody.innerHTML = '';
            if (!data || data.length === 0) {
                tariffTableBody.innerHTML = '<tr><td colspan="5">Тарифы еще не созданы.</td></tr>';
                return;
            }
            data.forEach(t => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${t.title}</td>
                    <td>${t.description || ''}</td>
                    <td>${formatExtensionsForDisplay(t.extensions)}</td>
                    <td>${t.is_active ? 'Да' : 'Нет'}</td>
                    <td>
                        <button type="button" class="edit-tariff-btn" data-id="${t.id}">Ред.</button>
                        <button type="button" class="delete-tariff-btn" data-id="${t.id}">Удалить</button>
                    </td>`;
                tariffTableBody.appendChild(tr);
            });
        } catch (err) {
            console.error('Ошибка загрузки тарифов:', err);
            tariffTableBody.innerHTML = `<tr><td colspan="5">Ошибка: ${err.message}</td></tr>`;
        }
    }

    tariffForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const id = tariffIdInput.value;
        const extArr = getExtensionsFromForm();
        const newTariffData = {
            title: tariffTitleInput.value,
            description: tariffDescriptionInput.value,
            is_active: tariffActiveCheckbox.checked,
            price_rub: extArr.length > 0 ? extArr[0].cost : 0, // for legacy compatibility
            duration_days: extArr.length > 0 ? extArr[0].days : 0, // for legacy compatibility
            slug: tariffTitleInput.value.trim().toLowerCase().replace(/\s+/g, '-'),
            extensions: extArr
        };
        try {
            const { error } = id
                ? await supabase.from('tariffs').update(newTariffData).eq('id', id)
                : await supabase.from('tariffs').insert([newTariffData]);
            if (error) throw error;
            await loadTariffs();
            resetTariffForm();
        } catch (err) {
            alert('Ошибка сохранения тарифа: ' + err.message);
        }
    });

    tariffTableBody.addEventListener('click', async (e) => {
        const editBtn = e.target.closest('.edit-tariff-btn');
        if (editBtn) {
            editTariff(editBtn.dataset.id);
            return;
        }

        const deleteBtn = e.target.closest('.delete-tariff-btn');
        if (deleteBtn) {
            const id = deleteBtn.dataset.id;
            if (confirm(`Вы уверены, что хотите удалить тариф с ID ${id}? Это действие необратимо.`)) {
                try {
                    const { error } = await supabase.from('tariffs').delete().eq('id', id);
                    if (error) throw error;
                    alert('Тариф успешно удален.');
                    loadTariffs();
                } catch (err) {
                    alert('Ошибка удаления: ' + err.message);
                }
            }
        }
    });

    async function editTariff(id) {
        try {
            const { data, error } = await supabase.from('tariffs').select('*').eq('id', id).single();
            if (error) throw error;
            tariffIdInput.value = data.id;
            tariffTitleInput.value = data.title;
            tariffDescriptionInput.value = data.description || '';
            tariffActiveCheckbox.checked = data.is_active;
            renderExtensions(data.extensions);
            tariffFormTitle.textContent = 'Редактировать тариф';
            tariffCancelBtn.classList.remove('hidden');
        } catch (err) {
            alert('Ошибка загрузки тарифа для редактирования: ' + err.message);
        }
    }

    function resetTariffForm() {
        tariffForm.reset();
        tariffIdInput.value = '';
        if (extensionsList) extensionsList.innerHTML = '';
        tariffFormTitle.textContent = 'Создать новый тариф';
        tariffCancelBtn.classList.add('hidden');
    }

    tariffCancelBtn.addEventListener('click', resetTariffForm);

    // --- Clients Logic ---

    async function loadClients() {
    clientsTableBody.innerHTML = '<tr><td colspan="7">Загрузка клиентов...</td></tr>'; // Увеличили colspan до 7
    try {
        const { data, error } = await supabase
            .from('clients')
            .select('*')
            .order('created_at', { ascending: false });

        if (error) throw error;
        clientsData = data || []; 
        clientsTableBody.innerHTML = '';

        if (clientsData.length === 0) {
            clientsTableBody.innerHTML = '<tr><td colspan="7">Клиенты не найдены.</td></tr>';
            return;
        }

        clientsData.forEach(client => {
            const tr = document.createElement('tr');
            const date = new Date(client.created_at).toLocaleDateString();
            const status = client.verification_status || 'not_set'; // Статус по умолчанию
            
            let statusBadge = '';
            switch(status) {
                case 'approved':
                    statusBadge = '<span class="status-badge status-approved">Одобрен</span>';
                    break;
                case 'rejected':
                    statusBadge = '<span class="status-badge status-rejected">Отклонен</span>';
                    break;
                case 'pending':
                    statusBadge = '<span class="status-badge status-pending">На проверке</span>';
                    break;
                default:
                    statusBadge = '<span>Не задан</span>';
            }

            // Добавляем кнопки верификации только для тех, кто на проверке
            const verificationButtons = status === 'pending'
                ? `<button type="button" class="approve-btn" data-id="${client.id}">Одобрить</button>
                   <button type="button" class="reject-btn" data-id="${client.id}">Отклонить</button>`
                : '';

            tr.innerHTML = `
                <td>${client.name}</td>
                <td>${client.phone || ''}</td>
                <td>${statusBadge}</td>
                <td>${date}</td>
                <td><button type="button" class="view-client-btn" data-id="${client.id}">Инфо/Фото</button></td>
                <td><button type="button" class="edit-client-btn" data-id="${client.id}">Ред. данных</button></td>
                <td>${verificationButtons}</td>`;
            clientsTableBody.appendChild(tr);
        });
    } catch (err) {
        console.error('Ошибка загрузки клиентов:', err);
        clientsTableBody.innerHTML = `<tr><td colspan="7">Ошибка: ${err.message}</td></tr>`;
    }
}
  
clientsTableBody.addEventListener('click', async (e) => {
    const target = e.target;
    const clientId = target.dataset.id;

    if (!clientId) return;

    let newStatus = '';
    if (target.classList.contains('approve-btn')) newStatus = 'approved';
    if (target.classList.contains('reject-btn')) newStatus = 'rejected';

    if (newStatus) {
        if (!confirm(`Вы уверены, что хотите изменить статус клиента #${clientId} на "${newStatus}"?`)) return;
        
        try {
            const { error } = await supabase
                .from('clients')
                .update({ verification_status: newStatus })
                .eq('id', clientId);

            if (error) throw error;
            
            alert('Статус клиента успешно обновлен!');
            loadClients(); // Перезагружаем список, чтобы увидеть изменения
        } catch (err) {
            alert(`Ошибка обновления статуса: ${err.message}`);
        }
    }
});
    // --- Rentals and Payments Loaders ---

    async function loadRentals() {
        const tbody = document.querySelector('#rentals-table tbody');
        tbody.innerHTML = '<tr><td colspan="6">Загрузка...</td></tr>';
        try {
            const { data, error } = await supabase
                .from('rentals')
                .select('id, starts_at, ends_at, status, clients (name), tariffs (title)')
                .order('starts_at', { ascending: false });
            if (error) throw error;
            tbody.innerHTML = '';
            data.forEach(r => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${r.clients?.name || 'Н/Д'}</td>
                    <td>${r.tariffs?.title || 'Н/Д'}</td>
                    <td>${new Date(r.starts_at).toLocaleString()}</td>
                    <td>${new Date(r.ends_at).toLocaleString()}</td>
                    <td>${r.status}</td>
                    <td><button type="button" class="close-rental-btn" data-id="${r.id}">Закрыть</button></td>`;
                tbody.appendChild(tr);
            });
        } catch (err) {
            tbody.innerHTML = `<tr><td colspan="6">Ошибка загрузки аренд: ${err.message}</td></tr>`;
        }
    }
    
    async function loadPayments() {
        const tbody = document.querySelector('#payments-table tbody');
        tbody.innerHTML = '<tr><td colspan="5">Загрузка...</td></tr>';
        try {
            const { data, error } = await supabase
                .from('payments')
                .select('id, amount_rub, method, status, created_at, clients (name)')
                .order('created_at', { ascending: false });
            if (error) throw error;
            tbody.innerHTML = '';
            data.forEach(p => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${p.clients?.name || 'Н/Д'}</td>
                    <td>${p.amount_rub}</td>
                    <td>${p.method}</td>
                    <td>${p.status}</td>
                    <td>${new Date(p.created_at).toLocaleString()}</td>`;
                tbody.appendChild(tr);
            });
        } catch (err) {
            tbody.innerHTML = `<tr><td colspan="5">Ошибка загрузки платежей: ${err.message}</td></tr>`;
        }
    }

    // --- Client Info/Edit Modals Logic ---
    // --- Client Info/Edit Modals Logic ---
// --- Client Info/Edit Modals Logic ---
// --- Client Info/Edit Modals Logic ---
if (clientsSection) {
    clientsSection.addEventListener('click', async (e) => {
        const viewBtn = e.target.closest('.view-client-btn');
        const editBtn = e.target.closest('.edit-client-btn');
        if (!viewBtn && !editBtn) return;

        const clientId = parseInt(viewBtn ? viewBtn.dataset.id : editBtn.dataset.id, 10);
        const client = clientsData.find(c => c.id === clientId);
        if (!client) return;

        const recognizedData = client.extra?.recognized_data || {};

        // --- ЛОГИКА ДЛЯ ПРОСМОТРА ИНФОРМАЦИИ И ФОТО ---
        if (viewBtn) {
            const recognizedContainer = document.getElementById('recognized-data-container');
            const photoLinksDiv = document.getElementById('photo-links');

            if (!clientInfoOverlay || !recognizedContainer || !photoLinksDiv) {
                console.error('Ошибка: один или несколько элементов модального окна не найдены в HTML.');
                alert('Ошибка интерфейса: не найдены элементы для отображения информации. Проверьте HTML-структуру.');
                return;
            }

            // Заполняем текстовые данные
            recognizedContainer.innerHTML = '';
            if (Object.keys(recognizedData).length > 0) {
                for (const key in recognizedData) {
                    recognizedContainer.innerHTML += `<div><strong>${key}:</strong> ${recognizedData[key] || 'Н/Д'}</div>`;
                }
            } else {
                recognizedContainer.innerHTML = '<p>Распознанные данные отсутствуют.</p>';
            }

            // Показываем оверлей и начинаем загрузку фото
            photoLinksDiv.innerHTML = 'Загрузка...';
            clientInfoOverlay.classList.remove('hidden');

            // Запрашиваем и отображаем ссылки на фото
            try {
                const { data: files, error } = await supabase.storage.from('passports').list(client.id.toString());
                if (error) throw error;

                if (!files || files.length === 0) {
                    photoLinksDiv.innerHTML = '<p>Фото не найдены.</p>';
                } else {
                    // ===== ИЗМЕНЕНИЕ ЗДЕСЬ =====
                    // Вместо текстовой ссылки создаем тег <img>, обернутый в ссылку
                    const links = files.map(file => {
                        const { data } = supabase.storage.from('passports').getPublicUrl(`${client.id}/${file.name}`);
                        return `
                            <a href="${data.publicUrl}" target="_blank" rel="noopener noreferrer" title="Нажмите, чтобы открыть в полном размере">
                                <img src="${data.publicUrl}" alt="${file.name}" style="max-width: 100%; height: auto; display: block; margin-bottom: 10px; border-radius: 8px; border: 1px solid #eee;">
                            </a>
                        `;
                    });
                    photoLinksDiv.innerHTML = links.join('');
                }
            } catch (err) {
                console.error('Ошибка загрузки фото:', err);
                photoLinksDiv.innerHTML = `<p style="color: red;">Ошибка загрузки фото: ${err.message}</p>`;
            }
        }

        // --- ЛОГИКА ДЛЯ РЕДАКТИРОВАНИЯ ---
        if (editBtn) {
            clientEditForm.innerHTML = '';
            for (const key in recognizedData) {
                const longFieldKeys = ['Кем выдан', 'Адрес регистрации', 'Адрес регистрации в РФ'];
                let inputEl;
                if (longFieldKeys.includes(key)) {
                    inputEl = `<textarea name="${key}" rows="2">${recognizedData[key] || ''}</textarea>`;
                } else {
                    inputEl = `<input type="text" name="${key}" value="${recognizedData[key] || ''}">`;
                }
                clientEditForm.innerHTML += `<div class="form-group"><label>${key}</label>${inputEl}</div>`;
            }
            currentEditingId = client.id;
            currentEditingExtra = client.extra;
            clientEditOverlay.classList.remove('hidden');
        }
    });
}

    if (clientInfoCloseBtn) {
        clientInfoCloseBtn.addEventListener('click', () => clientInfoOverlay.classList.add('hidden'));
    }
    if (typeof clientInfoCloseBtn2 !== 'undefined' && clientInfoCloseBtn2) {
        clientInfoCloseBtn2.addEventListener('click', () => clientInfoOverlay.classList.add('hidden'));
    }
    if (typeof imageViewerOverlay !== 'undefined' && imageViewerOverlay) {
        const closer = document.getElementById('image-viewer-close');
        if (closer) closer.addEventListener('click', () => imageViewerOverlay.classList.add('hidden'));
        imageViewerOverlay.addEventListener('click', (e) => { if (e.target === imageViewerOverlay) imageViewerOverlay.classList.add('hidden'); });
    }

    if (clientEditCancelBtn) {
        clientEditCancelBtn.addEventListener('click', () => clientEditOverlay.classList.add('hidden'));
    }
    
    if (clientEditSaveBtn) {
        clientEditSaveBtn.addEventListener('click', async () => {
            if (!currentEditingId) return;

            const updatedRec = {};
            clientEditForm.querySelectorAll('input, textarea').forEach(inp => {
                updatedRec[inp.name] = inp.value.trim();
            });
            
            // Создаем новый объект `extra` на основе старого, но с обновленными данными
            const extraObj = JSON.parse(JSON.stringify(currentEditingExtra || {}));
            extraObj.recognized_data = updatedRec;

            try {
                const { error } = await supabase
                    .from('clients')
                    .update({ extra: extraObj })
                    .eq('id', currentEditingId);
                if (error) throw error;
                
                alert('Данные клиента успешно обновлены.');
                clientEditOverlay.classList.add('hidden');
                await loadClients(); // Перезагружаем список клиентов для отображения изменений
            } catch (err) {
                alert('Ошибка сохранения данных: ' + err.message);
            }
        });
    }

    // Enhanced viewer/editor for client info within the info overlay
    if (clientsSection) {
        clientsSection.addEventListener('click', async (e) => {
            const btn = e.target.closest('.view-client-btn');
            if (!btn) return;
            const clientId = parseInt(btn.dataset.id, 10);
            try {
                // небольшая задержка, чтобы базовый обработчик показал модалку
                setTimeout(async () => {
                    const recWrap = document.getElementById('recognized-data-container');
                    const recView = document.getElementById('recognized-display');
                    const recForm = document.getElementById('recognized-edit-form');
                    const photosDiv = document.getElementById('photo-links');
                    if (!recWrap || !recView || !recForm || !photosDiv) return;

                    const { data: client, error } = await supabase.from('clients').select('*').eq('id', clientId).single();
                    if (error) throw error;
                    const rec = client?.extra?.recognized_data || {};

                    // render view
                    recView.innerHTML = '';
                    const keys = Object.keys(rec);
                    if (keys.length === 0) {
                        recView.innerHTML = '<p>Данных распознавания нет.</p>';
                    } else {
                        keys.forEach(k => {
                            const row = document.createElement('div');
                            row.className = 'info-row';
                            row.innerHTML = `<strong>${k}:</strong><span>${rec[k] ?? ''}</span>`;
                            recView.appendChild(row);
                        });
                    }

                    // render form
                    recForm.innerHTML = '';
                    keys.forEach(k => {
                        const block = document.createElement('div');
                        block.className = 'form-group';
                        block.innerHTML = `<label>${k}</label><input type="text" name="${k}" value="${(rec[k] ?? '').toString().replace(/"/g,'&quot;')}">`;
                        recForm.appendChild(block);
                    });
                    recForm.classList.add('hidden');
                    recView.classList.remove('hidden');
                    if (clientInfoEditToggle) clientInfoEditToggle.classList.remove('hidden');
                    if (clientInfoSaveBtn) clientInfoSaveBtn.classList.add('hidden');
                    
                    // edit toggle
                    if (clientInfoEditToggle) {
                        clientInfoEditToggle.onclick = () => {
                            const editing = !recForm.classList.contains('hidden');
                            if (editing) {
                                recForm.classList.add('hidden');
                                recView.classList.remove('hidden');
                                if (clientInfoSaveBtn) clientInfoSaveBtn.classList.add('hidden');
                                clientInfoEditToggle.textContent = 'Редактировать';
                            } else {
                                recForm.classList.remove('hidden');
                                recView.classList.add('hidden');
                                if (clientInfoSaveBtn) clientInfoSaveBtn.classList.remove('hidden');
                                clientInfoEditToggle.textContent = 'Просмотр';
                            }
                        };
                    }
                    if (clientInfoSaveBtn) {
                        clientInfoSaveBtn.onclick = async () => {
                            const formData = new FormData(recForm);
                            const updated = {};
                            for (const [k,v] of formData.entries()) updated[k] = String(v);
                            const extraObj = JSON.parse(JSON.stringify(client.extra || {}));
                            extraObj.recognized_data = updated;
                            const { error: uerr } = await supabase.from('clients').update({ extra: extraObj }).eq('id', clientId);
                            if (uerr) { alert('Ошибка сохранения: ' + uerr.message); return; }
                            // refresh view
                            recView.innerHTML = '';
                            Object.keys(updated).forEach(k => {
                                const row = document.createElement('div');
                                row.className = 'info-row';
                                row.innerHTML = `<strong>${k}:</strong><span>${updated[k]}</span>`;
                                recView.appendChild(row);
                            });
                            clientInfoEditToggle.click();
                        };
                    }

                    // photos grid + lightbox
                    photosDiv.innerHTML = 'Загрузка...';
                    try {
                        const { data: files, error: ferr } = await supabase.storage.from('passports').list(String(clientId));
                        if (ferr) throw ferr;
                        if (!files || files.length === 0) {
                            photosDiv.innerHTML = '<p>Фото не найдены.</p>';
                        } else {
                            photosDiv.innerHTML = '';
                            files.forEach(file => {
                                const { data } = supabase.storage.from('passports').getPublicUrl(`${clientId}/${file.name}`);
                                const img = document.createElement('img');
                                img.src = data.publicUrl;
                                img.alt = file.name;
                                img.className = 'client-photo-thumb';
                                img.addEventListener('click', () => {
                                    const overlay = document.getElementById('image-viewer-overlay');
                                    const viewerImg = document.getElementById('image-viewer-img');
                                    if (overlay && viewerImg) {
                                        viewerImg.src = data.publicUrl;
                                        overlay.classList.remove('hidden');
                                    }
                                });
                                photosDiv.appendChild(img);
                            });
                            // На случай, если другой обработчик отрисовал <a>, перерисуем в превью
                            setTimeout(() => {
                                const anchors = photosDiv.querySelectorAll('a');
                                if (anchors.length) {
                                    const urls = Array.from(anchors).map(a => a.href);
                                    photosDiv.innerHTML = '';
                                    urls.forEach(u => {
                                        const img = document.createElement('img');
                                        img.src = u;
                                        img.className = 'client-photo-thumb';
                                        img.addEventListener('click', () => {
                                            const overlay = document.getElementById('image-viewer-overlay');
                                            const viewerImg = document.getElementById('image-viewer-img');
                                            if (overlay && viewerImg) { viewerImg.src = u; overlay.classList.remove('hidden'); }
                                        });
                                        photosDiv.appendChild(img);
                                    });
                                }
                            }, 600);
                        }
                    } catch (err2) {
                        console.error('Ошибка загрузки фото:', err2);
                        photosDiv.innerHTML = `<p style="color:red;">Ошибка загрузки фото: ${err2.message}</p>`;
                    }
                }, 0);
            } catch (err) {
                console.error('Ошибка подготовки карточки клиента:', err);
            }
        });
    }

    // --- Export Logic ---
    if (exportBtn) {
        exportBtn.addEventListener('click', async () => {
            try {
                const { data, error } = await supabase.from('clients').select('*');
                if (error) throw error;

                const headers = ['id', 'name', 'phone', 'city', 'tg_user_id', 'created_at'];
                const csvRows = [headers.join(',')];
                data.forEach(c => {
                    const row = headers.map(header => JSON.stringify(c[header] || ''));
                    csvRows.push(row.join(','));
                });

                const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = `clients_${new Date().toISOString().split('T')[0]}.csv`;
                link.click();
                URL.revokeObjectURL(url);
            } catch (err) {
                alert('Ошибка экспорта: ' + err.message);
            }
        });
    }

    // --- Initial Load ---
    checkSession();

    // ==== Templates Manager (Шаблоны договоров) ====
    const templatesSection = document.getElementById('templates-section');
    const templatesTableBody = document.querySelector('#templates-table tbody');
    const templateNewBtn = document.getElementById('template-new-btn');
    const templateSaveBtn = document.getElementById('template-save-btn');
    const templateIdInput = document.getElementById('template-id');
    const templateNameInput = document.getElementById('template-name');
    const templateActiveCheckbox = document.getElementById('template-active');
    const templateEditor = document.getElementById('template-editor');
    // duplicate removed: const contractTemplateSelect
    // duplicate removed: const chipsClient
    // duplicate removed: const chipsTariff
    // duplicate removed: const chipsRental
    // duplicate removed: const chipsAux
    // duplicate removed: const editorToolbar

    const PLACEHOLDERS = {
      client: [
        ['client.full_name','ФИО'], ['client.first_name','Имя'], ['client.last_name','Фамилия'], ['client.middle_name','Отчество'],
        ['client.passport_series','Серия паспорта'], ['client.passport_number','Номер паспорта'], ['client.issued_by','Кем выдан'],
        ['client.issued_at','Дата выдачи'], ['client.birth_date','Дата рождения'], ['client.city','Город'], ['client.address','Адрес']
      ],
      tariff: [ ['tariff.title','Тариф'], ['tariff.duration_days','Дней'], ['tariff.price_rub','Сумма ₽'] ],
      rental: [ ['rental.id','№ аренды'], ['rental.starts_at','Начало'], ['rental.ends_at','Конец'], ['rental.bike_id','ID велосипеда'] ],
      aux: [ ['now.date','Дата'], ['now.time','Время'] ]
    };

    function mountChips(container, items) {
      if (!container) return;
      container.innerHTML = '';
      items.forEach(([value,label]) => {
        const chip = document.createElement('span');
        chip.className = 'chip';
        chip.textContent = label;
        chip.title = `Вставить {{${value}}}`;
        chip.addEventListener('click', () => insertAtCaret(`{{${value}}}`));
        container.appendChild(chip);
      });
    }

    function insertAtCaret(text) {
      if (!templateEditor) return;
      templateEditor.focus();
      document.execCommand('insertText', false, text);
    }

    function toolbarAction(e) {
      const btn = e.target.closest('button[data-cmd]');
      if (!btn || !templateEditor) return;
      const cmd = btn.dataset.cmd;
      templateEditor.focus();
      document.execCommand(cmd, false, null);
    }

    // selection tracking inside editor
    function isWithinEditor(node){ return templateEditor && node && (node === templateEditor || templateEditor.contains(node)); }
    document.addEventListener('selectionchange', () => {
      const sel = window.getSelection ? window.getSelection() : null;
      if (!sel || sel.rangeCount === 0) return;
      const r = sel.getRangeAt(0);
      if (isWithinEditor(r.startContainer)) {
        lastSelRange = r.cloneRange();
      }
    });

    function insertAtSavedRange(token){
      if (!templateEditor) return;
      templateEditor.focus();
      const sel = window.getSelection();
      try{
        if (lastSelRange && isWithinEditor(lastSelRange.startContainer)) {
          sel.removeAllRanges();
          sel.addRange(lastSelRange);
        }
        const range = sel.rangeCount ? sel.getRangeAt(0) : null;
        if (range) {
          range.deleteContents();
          const span = document.createElement('span');
          span.className = 'ph';
          span.textContent = token;
          range.insertNode(span);
          // move caret after inserted
          range.setStartAfter(span);
          range.collapse(true);
          sel.removeAllRanges(); sel.addRange(range);
        } else {
          document.execCommand('insertText', false, token);
        }
      } catch {
        document.execCommand('insertText', false, token);
      }
      // highlight
      highlightPlaceholdersInEditor();
    }

    // --- Drag&Drop и подсветка плейсхолдеров ---
    function enableDnDForChips() {
      document.querySelectorAll('.chips .chip').forEach(chip => {
        if (chip.dataset.dnd === '1') return;
        chip.dataset.dnd = '1';
        chip.setAttribute('draggable', 'true');
        chip.addEventListener('dragstart', (e) => {
          const token = `{{${chip.title.replace('Вставить ', '').replace(/[{}]/g,'').trim()}}}`;
          e.dataTransfer.setData('text/plain', token);
          chip.classList.add('dragging');
        });
        chip.addEventListener('dragend', () => chip.classList.remove('dragging'));
        // после клика (вставки) подсветить
        chip.addEventListener('click', () => setTimeout(highlightPlaceholdersInEditor, 0));
      });
      if (templateEditor) {
        templateEditor.addEventListener('dragover', (e)=>{ e.preventDefault(); templateEditor.classList.add('drag-over'); });
        templateEditor.addEventListener('dragleave', ()=> templateEditor.classList.remove('drag-over'));
        templateEditor.addEventListener('drop', (e)=>{
          e.preventDefault();
          templateEditor.classList.remove('drag-over');
          const text = e.dataTransfer.getData('text/plain');
          if (text) {
            templateEditor.focus();
            document.execCommand('insertText', false, text);
            highlightPlaceholdersInEditor();
            templateEditor.classList.add('drop-anim');
            setTimeout(()=>templateEditor.classList.remove('drop-anim'), 300);
          }
        });
        templateEditor.addEventListener('blur', highlightPlaceholdersInEditor);
      }
    }

    function highlightPlaceholdersInEditor() {
      if (!templateEditor) return;
      try {
        let html = templateEditor.innerHTML;
        html = html.replace(/<span class=\"ph\">(.*?)<\/span>/g, '$1');
        html = html.replace(/(\{\{\s*[\w\.\-]+\s*\}\})/g, '<span class="ph">$1<\/span>');
        templateEditor.innerHTML = html;
      } catch {}
    }

    // Навешиваем кликовую вставку, которая сохраняет позицию курсора
    function addChipClickHandlers() {
      document.querySelectorAll('.chips .chip').forEach(chip => {
        if (chip.dataset.clickBound === '1') return;
        chip.dataset.clickBound = '1';
        chip.addEventListener('mousedown', (e) => e.preventDefault());
        chip.addEventListener('click', () => {
          const m = /\{\{.*?\}\}/.exec(chip.title || '');
          const token = m ? m[0] : `{{${chip.textContent.trim()}}}`;
          insertAtSavedRange(token);
        });
      });
    }

    // --- Предпросмотр шаблона ---
    const templatePreviewBtn = document.getElementById('template-preview-btn');
    const templatePreviewOverlay = document.getElementById('template-preview-overlay');
    const templatePreviewContent = document.getElementById('template-preview-content');
    const templatePreviewClose = document.getElementById('template-preview-close');

    function pathGet(obj, path){ try{ return path.split('.').reduce((o,k)=>(o&&o[k]!=null)?o[k]:'', obj); }catch{return ''} }
    function buildPreviewHTML(){
      const ctx = {
        client:{ full_name:'Иванов Иван Иванович', first_name:'Иван', last_name:'Иванов', middle_name:'Иванович', passport_series:'12 34', passport_number:'567890', issued_by:'ОВД г. Москва', issued_at:'01.01.2020', birth_date:'02.02.1990', city:'Москва', address:'ул. Пушкина, д.1' },
        tariff:{ title:'Золотой', duration_days:7, price_rub:3750 },
        rental:{ id:12345, starts_at:'2025-09-01', ends_at:'2025-09-08', bike_id:'00001' },
        now:{ date: new Date().toLocaleDateString('ru-RU'), time: new Date().toLocaleTimeString('ru-RU') }
      };
      let html = templateEditor ? templateEditor.innerHTML : '';
      html = html.replace(/\{\{\s*([\w\.\-]+)\s*\}\}/g, (_,k)=>{ const v = pathGet(ctx,k); return v===undefined? '': String(v)});
      return html;
    }
    function openTemplatePreview(){ if (!templatePreviewOverlay||!templatePreviewContent) return; templatePreviewContent.innerHTML = buildPreviewHTML(); templatePreviewOverlay.classList.remove('hidden'); }
    function closeTemplatePreview(){ if (templatePreviewOverlay) templatePreviewOverlay.classList.add('hidden'); }
    if (templatePreviewBtn) templatePreviewBtn.addEventListener('click', openTemplatePreview);
    if (templatePreviewClose) templatePreviewClose.addEventListener('click', closeTemplatePreview);
    if (templatePreviewOverlay) templatePreviewOverlay.addEventListener('click', (e)=>{ if (e.target === templatePreviewOverlay) closeTemplatePreview(); });

    async function loadTemplates() {
      try {
        // chips
        mountChips(chipsClient, PLACEHOLDERS.client);
        mountChips(chipsTariff, PLACEHOLDERS.tariff);
        mountChips(chipsRental, PLACEHOLDERS.rental);
        mountChips(chipsAux, PLACEHOLDERS.aux);
        addChipClickHandlers();

        // включаем перетаскивание и постподсветку
        enableDnDForChips();

        const { data, error } = await supabase.from('contract_templates').select('*').order('id', { ascending: true });
        if (error) throw error;
        if (templatesTableBody) {
          templatesTableBody.innerHTML = '';
          (data||[]).forEach(t => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
              <td>${t.name}</td>
              <td>${t.is_active ? 'Да' : 'Нет'}</td>
              <td class="table-actions">
                <button type="button" class="template-edit-btn" data-id="${t.id}">Ред.</button>
                <button type="button" class="template-delete-btn" data-id="${t.id}">Удалить</button>
              </td>`;
            templatesTableBody.appendChild(tr);
          });
        }
        if (contractTemplateSelect) {
          const selected = contractTemplateSelect.value;
          contractTemplateSelect.innerHTML = '<option value="">— Не выбран —</option>' + (data||[]).map(t => `<option value="${t.id}">${t.name}</option>`).join('');
          if (selected) contractTemplateSelect.value = selected;
        }
      } catch (err) {
        console.error('Ошибка загрузки шаблонов:', err);
      }
    }

    async function saveTemplate() {
      if (!templateEditor) return;
      const id = (document.getElementById('template-id')||{}).value;
      const name = (document.getElementById('template-name')||{}).value || 'Без названия';
      const isActive = (document.getElementById('template-active')||{checked:true}).checked;
      const content = templateEditor.innerHTML || '';
      const rec = { name, content, is_active: isActive, placeholders: PLACEHOLDERS };
      try {
        let resp;
        if (id) resp = await supabase.from('contract_templates').update(rec).eq('id', id).select('id').single();
        else resp = await supabase.from('contract_templates').insert([rec]).select('id').single();
        if (resp.error) throw resp.error;
        document.getElementById('template-id').value = resp.data?.id || id || '';
        await loadTemplates();
        alert('Шаблон сохранён');
      } catch (err) {
        alert('Ошибка сохранения шаблона: ' + err.message);
      }
    }

    function newTemplate() {
      (document.getElementById('template-id')||{}).value = '';
      (document.getElementById('template-name')||{}).value = '';
      (document.getElementById('template-active')||{}).checked = true;
      if (templateEditor) templateEditor.innerHTML = '';
    }

    if (editorToolbar) editorToolbar.addEventListener('click', toolbarAction);
    document.getElementById('templates-table')?.addEventListener('click', async (e) => {
      const editBtn = e.target.closest('.template-edit-btn');
      const delBtn = e.target.closest('.template-delete-btn');
      if (editBtn) {
        const id = editBtn.dataset.id;
        const { data, error } = await supabase.from('contract_templates').select('*').eq('id', id).single();
        if (!error && data) {
          document.getElementById('template-id').value = data.id;
          document.getElementById('template-name').value = data.name;
          document.getElementById('template-active').checked = !!data.is_active;
          if (templateEditor) templateEditor.innerHTML = data.content || '';
        }
      }
      if (delBtn) {
        const id = delBtn.dataset.id;
        if (!confirm('Удалить шаблон?')) return;
        const { error } = await supabase.from('contract_templates').delete().eq('id', id);
        if (error) alert('Ошибка удаления: ' + error.message);
        await loadTemplates();
      }
    });
    if (templateSaveBtn) templateSaveBtn.addEventListener('click', saveTemplate);
    if (templateNewBtn) templateNewBtn.addEventListener('click', newTemplate);

    // Попробуем заранее загрузить шаблоны (для выпадающего списка у тарифов)
    loadTemplates().catch(()=>{});
});
